## Discord Bot Site Altyapısı!

## 📑 Site Özellikleri

- [x] Sade Tasarım
- [x] Politika Sayfaları
- [x] Özellikler 
